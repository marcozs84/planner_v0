package com.atlassian.jira_soapclient;

import _soapclient.JiraSoapService;
import _soapclient.JiraSoapServiceService;
import _soapclient.JiraSoapServiceServiceLocator;
import com.atlassian.jira.rpc.soap.beans.*;

import javax.xml.rpc.ServiceException;
import java.io.*;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.rmi.RemoteException;
import java.util.Calendar;
import java.util.Date;


/**
  * Sample JIRA SOAP client. Note that the constants sit in the {@link ClientConstants} interface
 */
public class SOAPClient
{

    JiraSoapServiceService jiraSoapServiceGetter;
    JiraSoapService jiraSoapService;
    String token;

    public SOAPClient() throws ServiceException, java.rmi.RemoteException
    {
        jiraSoapServiceGetter = new JiraSoapServiceServiceLocator();
        jiraSoapService = jiraSoapServiceGetter.getJirasoapserviceV2();
        login();
    }

    public void login() throws RemoteException
    {
        token = jiraSoapService.login(ClientConstants.LOGIN_NAME, ClientConstants.LOGIN_PASSWORD);
    }

    // To edit the constants, see the ClientConstants interface
    public static void main(String[] args) throws Exception
    {
        System.out.println("Running test SOAP client...");
        SOAPClient soapClient = new SOAPClient();

        final RemoteIssue issue = soapClient.testCreateIssue();
        soapClient.testAddAttachment(issue);

        String issueKey = issue.getKey();

        soapClient.testGetIssueById(issue.getId());
        soapClient.testAddComment(issueKey);
        soapClient.testGetFilters();
        soapClient.testGetIssues();
        soapClient.testFindIssuesWithTerm(ClientConstants.SEARCH_TERM);
        soapClient.testGetIssueCountForFilter(ClientConstants.FILTER_ID);

        soapClient.testGetCustomFieldValues(issueKey);

        // All the tests below need extra permissions. Enable in your own environment
        soapClient.testGetRemoteConfiguration();
        soapClient.testProgressWorkflow(issueKey);

        soapClient.testUpdateIssue(issueKey);

        soapClient.testGetCustomFields();

        soapClient.testCreateVersion();
        soapClient.testGetAllPermissions();

        soapClient.testDeleteProject(soapClient.testCreateProject());

        soapClient.testUpdateGroup();

    }

    public RemoteUser testAddUser(String username, String password, String fullname, String email) throws RemoteException
    {
        System.out.println("Testing create User: " + username);
        RemoteUser remoteUser = jiraSoapService.createUser(token, username, password, fullname, email);
        System.out.println("Successfully created User: " + username);
        return remoteUser;
    }

    public RemoteCustomFieldValue[] testGetCustomFieldValues(String issueKey)  throws RemoteException
    {
        System.out.println("Testing getting Custom Field values for Issue "+issueKey);
        RemoteField[] remoteFields = jiraSoapService.getCustomFields(token);

        // Get an issue with CustomField Values set.
        RemoteIssue issue = jiraSoapService.getIssue(token, issueKey);
        RemoteCustomFieldValue[] customFieldValues = issue.getCustomFieldValues();
        for(int i = 0; i < customFieldValues.length ; i++)
        {
            System.out.println("Custom Field Id: "+customFieldValues[i].getCustomfieldId());
            String[] values = customFieldValues[i].getValues();
            for(int j = 0; j < values.length ; j++)
            {
                System.out.println("Custom Field Value: "+values[j]);
            }
        }
        System.out.println("Ending getting Custom Field values for Issue "+issueKey);
        return customFieldValues;
    }

    public RemoteIssue testGetIssueById(String issueId) throws RemoteException
    {
        System.out.println("Testing getIssueById ...");
        RemoteIssue issue = jiraSoapService.getIssueById(token, issueId);
        System.out.println("Returned an issue id: "+issue.getId()+" key: "+issue.getKey());
        return issue;
    }

    public RemoteConfiguration testGetRemoteConfiguration() throws RemoteException
    {
        System.out.println("Testing getRemoteConfiguration ...");
        RemoteConfiguration config = jiraSoapService.getConfiguration(token);
        System.out.println("Returned Configuration: \nAllow Attachments: "+config.isAllowAttachments()+"\nAllow Issue Linking: "+config.isAllowIssueLinking());
        return config;
    }

    public long testGetIssueCountForFilter(String filterId)
            throws RemoteException
    {
        System.out.println("Testing getIssueCountForFilter ...");
        long issueCount = jiraSoapService.getIssueCountForFilter(token, filterId);
        System.out.println("Returned an issue count of "+issueCount+" for filter "+filterId);
        return issueCount;
    }

    public void testProgressWorkflow(String issueKey)
            throws java.rmi.RemoteException
    {
        System.out.println("Progressing workflow of "+issueKey+"...");
        RemoteNamedObject[] availableActions = jiraSoapService.getAvailableActions(token, issueKey);
        String actionId = null;
        for (int i = 0; i < availableActions.length; i++)
        {
            RemoteNamedObject availableAction = availableActions[i];
            System.out.println("availableAction: " + availableAction.getId() + " - " + availableAction.getName());
            if (actionId == null) actionId = availableAction.getId();
        }

        if (actionId != null)
        {
            RemoteField[] fieldsForAction = jiraSoapService.getFieldsForAction(token, issueKey, actionId);
            for (int i = 0; i < fieldsForAction.length; i++)
            {
                RemoteField remoteField = fieldsForAction[i];
                System.out.println("remoteField: " + remoteField.getId() + " - " + remoteField.getName());
            }

            RemoteFieldValue[] actionParams = new RemoteFieldValue[]{
                    new RemoteFieldValue("assignee", new String[]{ClientConstants.LOGIN_NAME})
            };

            RemoteIssue remoteIssue = jiraSoapService.progressWorkflowAction(token, issueKey, actionId, actionParams);
            System.out.println("Progressed workflow of "+remoteIssue.getKey()+" to: " + remoteIssue.getStatus());
        }
    }

    public void testUpdateGroup()
            throws java.rmi.RemoteException
    {
        System.out.println("Testing group update..");
        RemoteGroup group = jiraSoapService.getGroup(token, "jira-developers");
        System.out.println("Updating group: " + group.getName());
        System.out.println("group.getUsers(): " + (group.getUsers().length));


        RemoteUser[] remoteUsers = new RemoteUser[group.getUsers().length + 1];
        final RemoteUser[] oldUsers = group.getUsers();
        for (int i = 0; i < oldUsers.length; i++)
        {
            remoteUsers[i] = oldUsers[i];
        }
        RemoteUser newUser = new RemoteUser(null, null, "fred");
        System.out.println("newUser.getName() = " + newUser.getName());
        System.out.println("newUser.getFullname() = " + newUser.getFullname());

        remoteUsers[remoteUsers.length-1] = newUser;
        group.setUsers(remoteUsers);
        jiraSoapService.updateGroup(token, group);

        group = jiraSoapService.getGroup(token, "jira-developers");
        System.out.println("group: " + group);
        System.out.println("group.getUsers(): " + (group.getUsers().length));
    }

    public String testAddAttachment(RemoteIssue issue) throws IOException
    {
        File tmpFile = File.createTempFile("attachment", ".txt");
        FileWriter fw = new FileWriter(tmpFile);
        fw.write("A sample file attached via SOAP to JIRA issue "+issue.getKey());
        fw.close();

        String fileName = tmpFile.getName();
        boolean added = jiraSoapService.addAttachmentsToIssue(token,
                                                              issue.getKey(),
                                                              new String[]{fileName},
                                                              new byte[][]{getBytesFromFile(tmpFile)});
        System.out.println((added ? "Added" : "Failed to add") + " attachment "+fileName+" to issue "+issue.getKey());
        tmpFile.delete();
        return fileName;
    }

    public RemoteAttachment[] testGetAttachments(String issueKey) throws RemoteException
    {
        return jiraSoapService.getAttachmentsFromIssue(token, issueKey);
    }

    public RemotePermission [] testGetAllPermissions() throws java.rmi.RemoteException
    {
        RemotePermission[] allPermissions = jiraSoapService.getAllPermissions(token);
        for (int i = 0; i < allPermissions.length; i++)
        {
            RemotePermission allPermission = allPermissions[i];
            System.out.println("allPermission.getName(): " + allPermission.getName());
        }
        return allPermissions;
    }

    public RemoteVersion testCreateVersion() throws java.rmi.RemoteException
    {
        final RemoteVersion version = new RemoteVersion();
        version.setName("3 SOAP created version " + new Date());
        version.setSequence(new Long(6));
        version.setReleaseDate(Calendar.getInstance());
        final RemoteVersion createdVersion = jiraSoapService.addVersion(token, ClientConstants.PROJECT_KEY, version);
        System.out.println("createdVersion.getId(): " + createdVersion.getId());
        return createdVersion;
    }

    public void testReleaseVersion(RemoteVersion remoteVersion, String projectKey) throws java.rmi.RemoteException
    {
        jiraSoapService.releaseVersion(token, projectKey, remoteVersion);
    }

    public void testArchiveVersion(String projectKey, String versionName) throws java.rmi.RemoteException
    {
        jiraSoapService.archiveVersion(token, projectKey, versionName, true);
    }

    public RemoteField [] testGetCustomFields() throws java.rmi.RemoteException
    {
        final RemoteField[] customFields = jiraSoapService.getCustomFields(token);
        for (int i = 0; i < customFields.length; i++)
        {
            RemoteField customField = customFields[i];
            System.out.println("customField.getName(): " + customField.getName());
        }
        return customFields;
    }

    public RemoteFilter [] testGetFilters() throws java.rmi.RemoteException
    {
        System.out.println("All saved filters:");
        RemoteFilter[] savedFilters = jiraSoapService.getSavedFilters(token);
        for (int i = 0; i < savedFilters.length; i++)
        {
            RemoteFilter filter = savedFilters[i];
            String description = filter.getDescription() != null ?  (": " + filter.getDescription()) :  "";
            System.out.println("\t" + filter.getName() + description);
        }
        return savedFilters;
    }

    public RemoteIssue[] testGetIssues() throws java.rmi.RemoteException
    {
        RemoteIssue[] issues = jiraSoapService.getIssuesFromFilter(token, ClientConstants.FILTER_ID);
        for (int i = 0; i < issues.length; i++)
        {
            RemoteIssue issue = issues[i];
            System.out.println("issue.getSummary(): " + issue.getSummary());
        }
        return issues;
    }

    public RemoteIssue[] testFindIssuesWithTerm(String term) throws java.rmi.RemoteException
    {
        long startTime = System.currentTimeMillis();
        RemoteIssue[] issuesFromTextSearch = jiraSoapService.getIssuesFromTextSearch(token, term);
        System.out.println(issuesFromTextSearch.length + " issues with term \"" + term + "\"");
        for (int i = 0; i < issuesFromTextSearch.length; i++)
        {
            RemoteIssue remoteIssue = issuesFromTextSearch[i];
            System.out.println("\t"+remoteIssue.getKey() + " " + remoteIssue.getSummary());
        }
        System.out.println("Time taken for search: " + (System.currentTimeMillis() -startTime) + "ms");
        return issuesFromTextSearch;
    }

    public void testUpdateIssue(final String issueKey) throws java.rmi.RemoteException
    {
        testGetFieldsForEdit(issueKey);

        // Update the issue
        RemoteFieldValue[] actionParams = new RemoteFieldValue[]{
            new RemoteFieldValue("summary", new String[] {ClientConstants.NEW_SUMMARY}),
            new RemoteFieldValue(ClientConstants.CUSTOM_FIELD_KEY_1, new String[] {ClientConstants.CUSTOM_FIELD_VALUE_1}),
            new RemoteFieldValue(ClientConstants.CUSTOM_FIELD_KEY_2, new String[] {ClientConstants.CUSTOM_FIELD_VALUE_2})};

        jiraSoapService.updateIssue(token, issueKey, actionParams);
    }

    public void testGetFieldsForEdit(final String issueKey)
            throws java.rmi.RemoteException
    {
        // Editing the issue & getting the fields available on edit
        System.out.println("The issue " + issueKey + " has the following editable fields:");
        final RemoteField[] fieldsForEdit = jiraSoapService.getFieldsForEdit(token, issueKey);
        for (int i = 0; i < fieldsForEdit.length; i++)
        {
            RemoteField remoteField = fieldsForEdit[i];
            System.out.println("\tremoteField: " + remoteField.getId());
        }
    }

    /**
     * Add a blank comment.
     * <p/>
     * <strong>NOTE: this should fail.</strong>
     */
    public void testAddBlankComment(final String issueKey)
	   throws java.rmi.RemoteException
    {

        final RemoteComment comment = new RemoteComment();
        comment.setBody(null);
        jiraSoapService.addComment(token, issueKey, comment);
    }

    public RemoteComment[] testGetComments(final String issueKey)
        throws RemoteException
    {
        final RemoteComment[] comments = jiraSoapService.getComments(token, issueKey);
        return comments;
    }

    public void testAddComment(final String issueKey)
            throws java.rmi.RemoteException
    {
        // Adding a comment
        final RemoteComment comment = new RemoteComment();
        comment.setBody(ClientConstants.NEW_COMMENT_BODY);
        jiraSoapService.addComment(token, issueKey, comment);
    }

    public void testAddCommentWithVisibility(final String issueKey, final String groupLevel, final String roleLevel)
            throws java.rmi.RemoteException
    {
        // Adding a comment
        final RemoteComment comment = new RemoteComment();
        comment.setBody(ClientConstants.NEW_COMMENT_BODY);
        comment.setGroupLevel(groupLevel);
        comment.setRoleLevel(roleLevel);
        jiraSoapService.addComment(token, issueKey, comment);
    }

    public void testEditCommentAsIs(RemoteComment comment) throws RemoteException
    {
        jiraSoapService.editComment(token, comment);
    }

    public void testEditComment(RemoteComment comment) throws RemoteException
    {
        comment.setBody(ClientConstants.EDIT_COMMENT_BODY);
        jiraSoapService.editComment(token, comment);
    }

    public void testEditCommentWithVisibility(RemoteComment comment, final String groupLevel, final String roleLevel)
            throws RemoteException
    {
        comment.setBody(ClientConstants.EDIT_COMMENT_BODY);
        comment.setGroupLevel(groupLevel);
        comment.setRoleLevel(roleLevel);
        jiraSoapService.editComment(token, comment);
    }

    public boolean testHasPermissionToEditComment(RemoteComment comment) throws RemoteException
    {
        return jiraSoapService.hasPermissionToEditComment(token, comment);
    }

    public RemoteComment testGetComment(Long id) throws RemoteException
    {
        if (id != null)
        {
            return jiraSoapService.getComment(token, id.longValue());
        }
        return null;
    }

    public String testCreateProject()
            throws java.rmi.RemoteException
    {
        RemoteProject project = new RemoteProject();
        project.setKey(ClientConstants.CREATE_PROJECT_KEY);
        project.setLead(ClientConstants.LOGIN_NAME);
        project.setName(ClientConstants.PROJECT_NAME);
        project.setDescription(ClientConstants.PROJECT_DESCRIPTION);

        RemotePermissionScheme defaultPermScheme = new RemotePermissionScheme();
        defaultPermScheme.setId(new Long(0));
        project.setPermissionScheme(defaultPermScheme);

        RemoteProject returnedProject = testCreateProjectFromObject(project);

        final String projectKey = returnedProject.getKey();
        System.out.println("Created project " + projectKey);

        return projectKey;
    }

    public RemoteProject testCreateProjectFromObject(RemoteProject project) throws java.rmi.RemoteException
    {
        return jiraSoapService.createProjectFromObject(token, project);
    }

    public void testDeleteProject(String projectKey) throws java.rmi.RemoteException
    {
        jiraSoapService.deleteProject(token, projectKey);
        System.out.println("Deleted project "+projectKey);
    }

    public RemoteIssue testCreateIssue()
            throws java.rmi.RemoteException
    {
        // Create the issue
        RemoteIssue issue = new RemoteIssue();
        issue.setProject(ClientConstants.PROJECT_KEY);
        issue.setType(ClientConstants.ISSUE_TYPE_ID);

        issue.setSummary(ClientConstants.SUMMARY_NAME);
        issue.setPriority(ClientConstants.PRIORITY_ID);
        issue.setDuedate(Calendar.getInstance());
        issue.setAssignee("");

        // Add remote compoments
        RemoteComponent component = new RemoteComponent();
        component.setId(ClientConstants.COMPONENT_ID);
        issue.setComponents(new RemoteComponent[]{component});

        // Add remote versions
        RemoteVersion version = new RemoteVersion();
        version.setId(ClientConstants.VERSION_ID);
        RemoteVersion[] remoteVersions = new RemoteVersion[]{version};
        issue.setFixVersions(remoteVersions);

        // Add custom fields
        RemoteCustomFieldValue customFieldValue = new RemoteCustomFieldValue(ClientConstants.CUSTOM_FIELD_KEY_1, "", new String[]{ClientConstants.CUSTOM_FIELD_VALUE_1});
        RemoteCustomFieldValue customFieldValue2 = new RemoteCustomFieldValue(ClientConstants.CUSTOM_FIELD_KEY_2, "", new String[]{ClientConstants.CUSTOM_FIELD_VALUE_2});

        // Add a cascading select custom field
        RemoteCustomFieldValue customFieldValue3 = new RemoteCustomFieldValue(ClientConstants.CUSTOM_FIELD_KEY_3, null, new String[]{ClientConstants.CUSTOM_FIELD_VALUE_3});
        RemoteCustomFieldValue customFieldValue4 = new RemoteCustomFieldValue(ClientConstants.CUSTOM_FIELD_KEY_3, "1", new String[]{ClientConstants.CUSTOM_FIELD_VALUE_4});

        RemoteCustomFieldValue[] customFieldValues = new RemoteCustomFieldValue[] {customFieldValue, customFieldValue2, customFieldValue3, customFieldValue4};
        issue.setCustomFieldValues(customFieldValues);

        // Run the create issue code
        RemoteIssue returnedIssue = jiraSoapService.createIssue(token, issue);
        final String issueKey = returnedIssue.getKey();

        System.out.println("Successfully created issue " + issueKey);
        printIssueDetails(returnedIssue);

        return returnedIssue;
    }

    public RemoteProjectRole[] testGetProjectRoles() throws RemoteException
    {
        return jiraSoapService.getProjectRoles(token);
    }

    public RemoteProjectRole testGetProjectRole() throws RemoteException
    {
        // This will return the 'Users' role
        return jiraSoapService.getProjectRole(token, Long.parseLong(ClientConstants.USER_PROJECT_ROLE_ID));
    }

    public RemoteProjectRole testCreateRole(final String roleName) throws RemoteException
    {
        RemoteProjectRole projectRole = new RemoteProjectRole();
        projectRole.setName(roleName);

        return jiraSoapService.createProjectRole(token, projectRole);
    }

    public RemoteIssueType [] getIssueTypes(String userName, String password) throws RemoteException
    {
        String currentToken = getTokenForParams(userName, password);
        return jiraSoapService.getIssueTypes(currentToken);
    }

    public RemoteIssueType [] getSubTaskIssueTypes(String userName, String password) throws RemoteException
    {
        String currentToken = getTokenForParams(userName, password);
        return jiraSoapService.getSubTaskIssueTypes(currentToken);
    }

    public RemotePriority [] getPriorities(String userName, String password) throws RemoteException
    {
        String currentToken = getTokenForParams(userName, password);
        return jiraSoapService.getPriorities(currentToken);
    }

    public RemoteStatus [] getStatuses(String userName, String password) throws RemoteException
    {
        String currentToken = getTokenForParams(userName, password);
        return jiraSoapService.getStatuses(currentToken);
    }

    public RemoteResolution [] getResolutions(String userName, String password) throws RemoteException
    {
        String currentToken = getTokenForParams(userName, password);
        return jiraSoapService.getResolutions(currentToken);
    }

    private String getTokenForParams(String userName, String password) throws RemoteException
    {
        String currentToken;
        if (userName != null && password != null)
        {
            currentToken = jiraSoapService.login(userName, password);
        }
        else
        {
            currentToken = token;
        }
        return currentToken;
    }

    public void printIssueDetails(RemoteIssue issue)
    {
        System.out.println("Issue Details");
        Method[] declaredMethods = issue.getClass().getDeclaredMethods();
        for (int i = 0; i < declaredMethods.length; i++)
        {
            Method declaredMethod = declaredMethods[i];
            if (declaredMethod.getName().startsWith("get") && declaredMethod.getParameterTypes().length == 0)
            {
                System.out.print("Issue." + declaredMethod.getName() + "() -> ");
                try
                {
                    Object o = declaredMethod.invoke(issue, new Object[]{});
                    if (o instanceof Object[])
                        System.out.println(printArray((Object[]) o));
                    else
                        System.out.println(o);
                }
                catch (IllegalAccessException e)
                {
                    e.printStackTrace();
                }
                catch (InvocationTargetException e)
                {
                    e.printStackTrace();
                }
            }
        }
    }

    private String printArray(Object[] o)
    {
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < o.length; i++)
        {
            sb.append(o[i]).append(" ");
        }
        return sb.toString();
    }

    // Returns the contents of the file in a byte array.
    // From http://javaalmanac.com/egs/java.io/File2ByteArray.html
    private byte[] getBytesFromFile(File file) throws IOException
    {
        InputStream is = new FileInputStream(file);

        // Get the size of the file
        long length = file.length();

        // You cannot create an array using a long type.
        // It needs to be an int type.
        // Before converting to an int type, check
        // to ensure that file is not larger than Integer.MAX_VALUE.
        if (length < Integer.MAX_VALUE)
        {
            // Create the byte array to hold the data
            byte[] bytes = new byte[(int) length];

            // Read in the bytes
            int offset = 0;
            int numRead = 0;
            while (offset < bytes.length
                   && (numRead = is.read(bytes, offset, bytes.length - offset)) >= 0)
            {
                offset += numRead;
            }

            // Ensure all the bytes have been read in
            if (offset < bytes.length)
            {
                throw new IOException("Could not completely read file " + file.getName());
            }

            // Close the input stream and return bytes
            is.close();
            return bytes;
        }
        else
        {
            System.out.println("File is too large");
            return null;
        }

    }

    public boolean testIsRoleNameUnique(final String roleName) throws RemoteException
    {
        return jiraSoapService.isProjectRoleNameUnique(token, roleName);
    }

    public void testDeleteRole(final RemoteProjectRole remoteProjectRole) throws RemoteException
    {
        jiraSoapService.deleteProjectRole(token, remoteProjectRole, true);
    }

    public void testAddActorsToProjectRole(RemoteProjectRole projectRole, RemoteProject remoteProject, String actor, String actorType) throws RemoteException
    {
        jiraSoapService.addActorsToProjectRole(token, new String[] {actor}, projectRole, remoteProject, actorType);
    }

    public void testRemoveActorsFromProjectRole(RemoteProjectRole projectRole, RemoteProject remoteProject, String actor, String actorType) throws RemoteException
    {
        jiraSoapService.removeActorsFromProjectRole(token, new String[] {actor}, projectRole, remoteProject, actorType);
    }

    public void testUpdateRole(String description) throws RemoteException
    {
        RemoteProjectRole projectRole = jiraSoapService.getProjectRole(token, 10000);

        projectRole.setDescription(description);

        jiraSoapService.updateProjectRole(token, projectRole);

    }

    public RemoteProjectRoleActors testGetProjectRoleActors() throws RemoteException
    {
        RemoteProjectRole projectRole = jiraSoapService.getProjectRole(token, 10000);

        RemoteProject remoteProject = new RemoteProject();
        remoteProject.setId("10001");
        remoteProject.setName("monkey");
        remoteProject.setKey("MKY");


        return jiraSoapService.getProjectRoleActors(token, projectRole,  remoteProject);
    }

    public RemoteRoleActors testGetDefaultRoleActors() throws RemoteException
    {
        RemoteProjectRole projectRole = jiraSoapService.getProjectRole(token, 10000);

        return jiraSoapService.getDefaultRoleActors(token, projectRole);
    }

    public void testAddDefaultActorsToProjectRole(RemoteProjectRole projectRole, String actorName, String type) throws RemoteException
    {
        jiraSoapService.addDefaultActorsToProjectRole(token, new String[] {actorName}, projectRole, type);
    }

    public void testRemoveDefaultActorsFromProjectRole(RemoteProjectRole projectRole, String actorName, String type) throws RemoteException
    {
        jiraSoapService.removeDefaultActorsFromProjectRole(token, new String[] {actorName}, projectRole, type);
    }

    public void testRemoveAllRoleActorsByNameAndType(final String name, final String type) throws RemoteException
    {
        jiraSoapService.removeAllRoleActorsByNameAndType(token, name, type);
    }

    public void testRemoveAllRoleActorsByProject(RemoteProject remoteProject) throws RemoteException
    {
        jiraSoapService.removeAllRoleActorsByProject(token, remoteProject);
    }

    public RemoteScheme[] testGetAssociatedNotificationSchemes(RemoteProjectRole remoteprojectRole) throws RemoteException
    {
        return jiraSoapService.getAssociatedNotificationSchemes(token, remoteprojectRole);
    }

    public RemoteScheme[] testGetAssociatedPermissionSchemes(RemoteProjectRole remoteprojectRole) throws RemoteException
    {
        return jiraSoapService.getAssociatedPermissionSchemes(token, remoteprojectRole);
    }

    public RemoteProject testGetProjectById(Long id) throws RemoteException
    {
        return jiraSoapService.getProjectById(token, id.longValue());
    }

    public RemoteProject testGetProjectByKey(String key) throws RemoteException
    {
        return jiraSoapService.getProjectByKey(token, key);
    }
}
